//
//  ValorMasa.swift
//  Tarea 2 Pizza para Apple Watch
//
//  Created by Israel Rodriguez Ibarra on 17/02/16.
//  Copyright © 2016 Israel Rodriguez Ibarra. All rights reserved.
//

import WatchKit

class ValorMasa: NSObject {
    var tamaño : String = ""
    var masa : String = ""
    
    init(t:String, m:String) {
        tamaño = t
        masa = m
    }

}
