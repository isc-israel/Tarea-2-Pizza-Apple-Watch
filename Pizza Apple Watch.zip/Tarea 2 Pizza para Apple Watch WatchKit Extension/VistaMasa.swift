//
//  VistaMasa.swift
//  Tarea 2 Pizza para Apple Watch
//
//  Created by Israel Rodriguez Ibarra on 15/02/16.
//  Copyright © 2016 Israel Rodriguez Ibarra. All rights reserved.
//

import WatchKit
import Foundation


class VistaMasa: WKInterfaceController {
    
    var tamaño : String = ""
    var masa : String = ""
    var valorMasa : Int = 0

    @IBOutlet var etiquetaMasa: WKInterfaceLabel!
    @IBOutlet var botonMasaOutlet: WKInterfaceButton!
   
    override func awakeWithContext(context: AnyObject?) {
        super.awakeWithContext(context)
        
        // Configure interface objects here.
        botonMasaOutlet.setEnabled(false)
        
        let t = context as! ValorTamano
        tamaño = t.tamaño
    }
    override func willActivate() {
        // This method is called when watch view controller is about to be visible to user
        super.willActivate()
    }
    override func didDeactivate() {
        // This method is called when watch view controller is no longer visible
        super.didDeactivate()
    }

    func seleccionMasa(value : Int ) -> String {
        valorMasa = value
        switch valorMasa {
        case 0:
            masa = "¡Sin selección!"
            etiquetaMasa.setText(masa)
            botonMasaOutlet.setEnabled(false)
        case 1:
            masa = "Delgada"
            etiquetaMasa.setText(masa)
            botonMasaOutlet.setEnabled(true)
        case 2:
            masa = "Crujiente"
            etiquetaMasa.setText(masa)
            botonMasaOutlet.setEnabled(true)
        case 3:
            masa = "Gruesa"
            etiquetaMasa.setText(masa)
            botonMasaOutlet.setEnabled(true)
        default:
            masa = "¡Sin selección!"
            etiquetaMasa.setText(masa)
            botonMasaOutlet.setEnabled(false)
        }
        return masa
    }

    @IBAction func sliderMasa(value: Int) {
        seleccionMasa(value)
        print(value,masa)
    }
    @IBAction func botonMasa() {
        let valorContexto = ValorMasa(t: tamaño, m: masa)
        pushControllerWithName("ID Masa", context: valorContexto)
    }
    
}
