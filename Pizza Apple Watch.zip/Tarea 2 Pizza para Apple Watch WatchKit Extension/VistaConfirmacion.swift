//
//  VistaConfirmacion.swift
//  Tarea 2 Pizza para Apple Watch
//
//  Created by Israel Rodriguez Ibarra on 16/02/16.
//  Copyright © 2016 Israel Rodriguez Ibarra. All rights reserved.
//

import WatchKit
import Foundation


class VistaConfirmacion: WKInterfaceController {

    @IBOutlet var seleccionTamaño: WKInterfaceLabel!
    @IBOutlet var seleccionMasa: WKInterfaceLabel!
    @IBOutlet var seleccionQueso: WKInterfaceLabel!
    @IBOutlet var seleccionIngrediente1: WKInterfaceLabel!
    @IBOutlet var seleccionIngrediente2: WKInterfaceLabel!
    @IBOutlet var seleccionIngrediente3: WKInterfaceLabel!
    @IBOutlet var seleccionIngrediente4: WKInterfaceLabel!
    @IBOutlet var seleccionIngrediente5: WKInterfaceLabel!
    
    override func awakeWithContext(context: AnyObject?) {
        super.awakeWithContext(context)
        
        // Configure interface objects here.
        let tmqi = context as! ValorIngredientes
        seleccionTamaño.setText(tmqi.tamaño)
        seleccionMasa.setText(tmqi.masa)
        seleccionQueso.setText(tmqi.queso)
        seleccionIngrediente1.setText(tmqi.ingrediente1)
        seleccionIngrediente2.setText(tmqi.ingrediente2)
        seleccionIngrediente3.setText(tmqi.ingrediente3)
        seleccionIngrediente4.setText(tmqi.ingrediente4)
        seleccionIngrediente5.setText(tmqi.ingrediente5)
    }
    override func willActivate() {
        // This method is called when watch view controller is about to be visible to user
        super.willActivate()
    }
    override func didDeactivate() {
        // This method is called when watch view controller is no longer visible
        super.didDeactivate()
    }

    @IBAction func botonConfirmacion() {
    }
}
