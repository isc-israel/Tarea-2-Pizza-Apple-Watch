//
//  ValorQueso.swift
//  Tarea 2 Pizza para Apple Watch
//
//  Created by Israel Rodriguez Ibarra on 18/02/16.
//  Copyright © 2016 Israel Rodriguez Ibarra. All rights reserved.
//

import WatchKit

class ValorQueso: NSObject {
    var tamaño : String = ""
    var masa : String = ""
    var queso : String = ""
    
    init(t:String, m:String, q:String) {
        tamaño = t
        masa = m
        queso = q
    }

}
