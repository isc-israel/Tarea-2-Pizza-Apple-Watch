//
//  InterfaceController.swift
//  Tarea 2 Pizza para Apple Watch WatchKit Extension
//
//  Created by Israel Rodriguez Ibarra on 15/02/16.
//  Copyright © 2016 Israel Rodriguez Ibarra. All rights reserved.
//

import WatchKit
import Foundation


class InterfaceController: WKInterfaceController {

    var tamaño: String = ""
    
    @IBOutlet var etiquetaTamaño: WKInterfaceLabel!
    @IBOutlet var slidersTamaño: WKInterfaceSlider!
    @IBOutlet var botonTamañoOutlet: WKInterfaceButton!


    override func awakeWithContext(context: AnyObject?) {
        super.awakeWithContext(context)
        
        // Configure interface objects here.
        botonTamañoOutlet.setEnabled(false)
    }
    override func willActivate() {
        // This method is called when watch view controller is about to be visible to user
        super.willActivate()
    }
    override func didDeactivate() {
        // This method is called when watch view controller is no longer visible
        super.didDeactivate()
    }
    
    func seleccionTamaño(value : Int) -> String {
        let valorTamaño = value
        switch valorTamaño {
        case 0:
            tamaño = "¡Sin selección!"
            etiquetaTamaño.setText(tamaño)
            botonTamañoOutlet.setEnabled(false)
        case 1:
            tamaño = "Chica"
            etiquetaTamaño.setText(tamaño)
            botonTamañoOutlet.setEnabled(true)
        case 2:
            tamaño = "Mediana"
            etiquetaTamaño.setText(tamaño)
            botonTamañoOutlet.setEnabled(true)
        case 3:
            tamaño = "Grande"
            etiquetaTamaño.setText(tamaño)
            botonTamañoOutlet.setEnabled(true)
        default:
            tamaño = "¡Sin selección!"
            etiquetaTamaño.setText(tamaño)
            botonTamañoOutlet.setEnabled(false)
        }
        return tamaño
    }

    @IBAction func sliderTamaño(value: Int) {
        seleccionTamaño(value)
        print(value,tamaño)
    }
    @IBAction func botonTamaño() {
        let valorContexto = ValorTamano(t: tamaño)
        pushControllerWithName("ID Tamaño", context: valorContexto)
    }

}
