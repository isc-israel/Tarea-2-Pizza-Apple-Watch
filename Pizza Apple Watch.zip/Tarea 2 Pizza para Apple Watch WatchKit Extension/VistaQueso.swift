//
//  VistaQueso.swift
//  Tarea 2 Pizza para Apple Watch
//
//  Created by Israel Rodriguez Ibarra on 15/02/16.
//  Copyright © 2016 Israel Rodriguez Ibarra. All rights reserved.
//

import WatchKit
import Foundation


class VistaQueso: WKInterfaceController {

    var tamaño : String = ""
    var masa : String = ""
    var queso : String = ""
    var valorQueso : Int = 0
    
    @IBOutlet var etiquetaQueso: WKInterfaceLabel!
    @IBOutlet var botonQuesoOutlet: WKInterfaceButton!
    
    override func awakeWithContext(context: AnyObject?) {
        super.awakeWithContext(context)

        // Configure interface objects here.
        botonQuesoOutlet.setEnabled(false)
        
        let tm = context as! ValorMasa
        tamaño = tm.tamaño
        masa = tm.masa
    }
    override func willActivate() {
        // This method is called when watch view controller is about to be visible to user
        super.willActivate()
    }
    override func didDeactivate() {
        // This method is called when watch view controller is no longer visible
        super.didDeactivate()
    }

    func seleccionQueso(value : Int) -> String {
        valorQueso = value
        switch valorQueso {
        case 0:
            queso = "¡Sin selección!"
            etiquetaQueso.setText(queso)
            botonQuesoOutlet.setEnabled(false)
        case 1:
            queso = "Mozarela"
            etiquetaQueso.setText(queso)
            botonQuesoOutlet.setEnabled(true)
        case 2:
            queso = "Cheddar"
            etiquetaQueso.setText(queso)
            botonQuesoOutlet.setEnabled(true)
        case 3:
            queso = "Parmesano"
            etiquetaQueso.setText(queso)
            botonQuesoOutlet.setEnabled(true)
        case 4:
            queso = "Sin Queso"
            etiquetaQueso.setText(queso)
            botonQuesoOutlet.setEnabled(true)
        default:
            queso = "¡Sin selección!"
            etiquetaQueso.setText(queso)
            botonQuesoOutlet.setEnabled(false)
        }
        return queso
    }

    @IBAction func sliderQueso(value: Int) {
        seleccionQueso(value)
        print(value,queso)
    }
    @IBAction func botonQueso() {
        let valorContexto = ValorQueso(t: tamaño, m: masa, q: queso)
        pushControllerWithName("ID Queso", context: valorContexto)
    }
}