//
//  VistaIngredientes.swift
//  Tarea 2 Pizza para Apple Watch
//
//  Created by Israel Rodriguez Ibarra on 15/02/16.
//  Copyright © 2016 Israel Rodriguez Ibarra. All rights reserved.
//

import WatchKit
import Foundation


class VistaIngredientes: WKInterfaceController {
    
    var tamaño : String = ""
    var masa : String = ""
    var queso : String = ""
    
    var w:String = ""
    var cont : Int = 0
    var flag : Bool = false
    var ingredientes : [String] = []
    var ing01 : String = "-"; var ing02 : String = "-"
    var ing03 : String = "-"; var ing04 : String = "-"
    var ing05 : String = "-";

    @IBOutlet var etiquetaIngredientes: WKInterfaceLabel!
    @IBOutlet var sw01: WKInterfaceSwitch!
    @IBOutlet var sw02: WKInterfaceSwitch!
    @IBOutlet var sw03: WKInterfaceSwitch!
    @IBOutlet var sw04: WKInterfaceSwitch!
    @IBOutlet var sw05: WKInterfaceSwitch!
    @IBOutlet var sw06: WKInterfaceSwitch!
    @IBOutlet var sw07: WKInterfaceSwitch!
    @IBOutlet var sw08: WKInterfaceSwitch!
    @IBOutlet var sw09: WKInterfaceSwitch!
    @IBOutlet var sw10: WKInterfaceSwitch!
    @IBOutlet var botonIngredientesOutlet: WKInterfaceButton!
    
    override func awakeWithContext(context: AnyObject?) {
        super.awakeWithContext(context)
        // Configure interface objects here.
        botonIngredientesOutlet.setEnabled(false)
        
        let tmq = context as! ValorQueso
        tamaño = tmq.tamaño
        masa = tmq.masa
        queso = tmq.queso
    }
    override func willActivate() {
        // This method is called when watch view controller is about to be visible to user
        super.willActivate()
        back()
    }
    override func didDeactivate() {
        // This method is called when watch view controller is no longer visible
        super.didDeactivate()
    }

    func limite(value:Bool, var salir:Bool, id:String) -> Bool {
        w = id
        if salir == false {
            switch value {
                case true:
                    cont++
                    if cont > 0 { botonIngredientesOutlet.setEnabled(true) }
                    if cont > 5 { flag = true; salir = true; cont-- }
                    else
                    { ingredientes+=[id]; print(ingredientes) }
                case false:
                    cont--; eliminarIngrediente(w); print(ingredientes)
                    if cont == 0 { botonIngredientesOutlet.setEnabled(false) }
                
            }
        }
        if salir == true {
            switch value {
                case true:
                    flag = true; salir = true; print(ingredientes)      // ¡Nunca se ejecuta!
                case false:
                    cont--; eliminarIngrediente(w); flag = false; salir = false; print(ingredientes)
            }
        }
        return flag
    }
    func eliminarIngrediente(w:String) {
        var x: Int = 0
        var flagTemp : Bool = false
        
        while flagTemp == false {
            if w == ingredientes[x] {
                ingredientes.removeAtIndex(x)
                flagTemp = true
            }
            x++
        }
    }
    func seleccionIngredientes() {
        ingredientes.sortInPlace()
        
        var pos : Int = 0
        for _ in ingredientes {
            switch ingredientes[pos] {
                case "01": ingredientes[pos] = "Jamón"
                case "02": ingredientes[pos] = "Pepperonni"
                case "03": ingredientes[pos] = "Pavo"
                case "04": ingredientes[pos] = "Salchicha"
                case "05": ingredientes[pos] = "Aceituna"
                case "06": ingredientes[pos] = "Cebolla"
                case "07": ingredientes[pos] = "Pimiento"
                case "08": ingredientes[pos] = "Piña"
                case "09": ingredientes[pos] = "Anchoa"
                case "10": ingredientes[pos] = "Champiñón"
                default: ingredientes[pos] = "¡Sin selección!"
            }
            pos++
        }
        print (ingredientes)
        
        switch ingredientes.count {
            case 1: ing01 = ingredientes[0]
            case 2: ing01 = ingredientes[0]; ing02 = ingredientes[1]
            case 3: ing01 = ingredientes[0]; ing02 = ingredientes[1]; ing03 = ingredientes[2]
            case 4: ing01 = ingredientes[0]; ing02 = ingredientes[1]; ing03 = ingredientes[2]; ing04 = ingredientes[3]
            case 5: ing01 = ingredientes[0]; ing02 = ingredientes[1]; ing03 = ingredientes[2]; ing04 = ingredientes[3]; ing05=ingredientes[4]
            default: ing01 = "-"; ing02 = "-"; ing03 = "-"; ing04 = "-"; ing05 = "-"
        }
        print (ingredientes)
    }
    func back() {
        var pos : Int = 0
        for _ in ingredientes {
            switch ingredientes[pos] {
                case "Jamón": ingredientes[pos] = "01"
                case "Pepperonni": ingredientes[pos] = "02"
                case "Pavo": ingredientes[pos] = "03"
                case "Salchicha": ingredientes[pos] = "04"
                case "Aceituna": ingredientes[pos] = "05"
                case "Cebolla": ingredientes[pos] = "06"
                case "Pimiento": ingredientes[pos] = "07"
                case "Piña": ingredientes[pos] = "08"
                case "Anchoa": ingredientes[pos] = "09"
                case "Champiñón": ingredientes[pos] = "10"
                default: ingredientes[pos] = "¡Sin selección!"
            }
            pos++
        }
        ing01="-"; ing02="-"; ing03="-"; ing04="-"; ing05="-"
    }
    
    @IBAction func sw01(value: Bool) {
        let identificador : String = "01"
        limite(value, salir: flag, id: identificador)
        if flag == true { sw01.setOn(false) }
    }
    @IBAction func sw02(value: Bool) {
        let identificador : String = "02"
        limite(value, salir: flag, id: identificador)
        if flag == true { sw02.setOn(false) }
    }
    @IBAction func sw03(value: Bool) {
        let identificador : String = "03"
        limite(value, salir: flag, id: identificador)
        if flag == true { sw03.setOn(false) }
    }
    @IBAction func sw04(value: Bool) {
        let identificador : String = "04"
        limite(value, salir: flag, id: identificador)
        if flag == true { sw04.setOn(false) }
    }
    @IBAction func sw05(value: Bool) {
        let identificador : String = "05"
        limite(value, salir: flag, id: identificador)
        if flag == true { sw05.setOn(false) }
    }
    @IBAction func sw06(value: Bool) {
        let identificador : String = "06"
        limite(value, salir: flag, id: identificador)
        if flag == true { sw06.setOn(false) }
    }
    @IBAction func sw07(value: Bool) {
        let identificador : String = "07"
        limite(value, salir: flag, id: identificador)
        if flag == true { sw07.setOn(false) }
    }
    @IBAction func sw08(value: Bool) {
        let identificador : String = "08"
        limite(value, salir: flag, id: identificador)
        if flag == true { sw08.setOn(false) }
    }
    @IBAction func sw09(value: Bool) {
        let identificador : String = "09"
        limite(value, salir: flag, id: identificador)
        if flag == true { sw09.setOn(false) }
    }
    @IBAction func sw10(value: Bool) {
        let identificador : String = "10"
        limite(value, salir: flag, id: identificador)
        if flag == true { sw10.setOn(false) }
    }
    @IBAction func botonIngredientes() {
        seleccionIngredientes()
        
        let valorContexto = ValorIngredientes(t: tamaño, m: masa, q: queso, i1: ing01, i2: ing02, i3: ing03, i4: ing04, i5: ing05)
        pushControllerWithName("Configuracion Pizza", context: valorContexto)
    }

}
