//
//  ValorTamano.swift
//  Tarea 2 Pizza para Apple Watch
//
//  Created by Israel Rodriguez Ibarra on 17/02/16.
//  Copyright © 2016 Israel Rodriguez Ibarra. All rights reserved.
//

import WatchKit

class ValorTamano: NSObject {
    var tamaño : String = ""
    
    init(t:String) {
        tamaño = t
    }

}
